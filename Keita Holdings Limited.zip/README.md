
  # Keita Holdings Limited

  This is a code bundle for Keita Holdings Limited. The original project is available at https://www.figma.com/design/Twk7LSCh1X3lcU5arTcSrj/Keita-Holdings-Limited.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  